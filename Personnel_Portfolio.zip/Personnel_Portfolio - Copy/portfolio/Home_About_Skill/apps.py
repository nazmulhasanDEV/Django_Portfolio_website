from django.apps import AppConfig


class HomeAboutSkillConfig(AppConfig):
    name = 'Home_About_Skill'
