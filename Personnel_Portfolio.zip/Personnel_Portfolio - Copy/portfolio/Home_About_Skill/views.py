from django.shortcuts import render,redirect, get_object_or_404
from main.models import Front_setting, About_page,  Skill

# Create your views here.

# home page starts

def add_home(request):

    if not request.user.is_authenticated:
        return render(request,'back/login.html')

    if request.method == 'POST':
        name = request.POST.get('name')
        intro_title = request.POST.get('intro_title')
        intro_description = request.POST.get('intro_description')
        intro_title1 = request.POST.get('intro_title1')
        email = request.POST.get('email')
        intro_description1 = request.POST.get('intro_description1')
        intro_description2 = request.POST.get('intro_description2')
        address1 = request.POST.get('address1')
        address2 = request.POST.get('address2')
        fb_link = request.POST.get('fb_link')
        linkedin_link = request.POST.get('linkedin_link')
        twt_link = request.POST.get('twt_link')
        instgram_link = request.POST.get('instgram_link')

        if name != "" and email != "":
            db = Front_setting.objects.get(pk=1)
            db.name=name
            db.intro_title=intro_title
            db.itro_desctiption=intro_description
            db.intro_title1=intro_title1
            db.intro_description1=intro_description1
            db.intro_description2=intro_description2
            db.email=email
            db.address1=address1
            db.address2=address2
            db.fb=fb_link
            db.linkedIn=linkedin_link
            db.twttr=twt_link
            db.instgrm=instgram_link
            db.save()
            return redirect('homePageData')
        else:
            notify = 'There is something wrong!'
            return render(request,'back/notify.html',{'notify':notify})
    return render(request, 'back/add_home.html')

def home_page_data(request):

    homePage_data = Front_setting.objects.get(pk=1)

    return render(request,'back/home_page_data.html',{'home_page_data':homePage_data})

def edit_homePage(request):

    if not request.user.is_authenticated:
        return render(request,'back/login.html')

    if request.method == 'POST':
        name = request.POST.get('name')
        intro_title = request.POST.get('intro_title')
        intro_description = request.POST.get('intro_description')
        intro_title1 = request.POST.get('intro_title1')
        email = request.POST.get('email')
        intro_description1 = request.POST.get('intro_description1')
        intro_description2 = request.POST.get('intro_description2')
        address1 = request.POST.get('address1')
        address2 = request.POST.get('address2')
        fb_link = request.POST.get('fb_link')
        linkedin_link = request.POST.get('linkedin_link')
        twt_link = request.POST.get('twt_link')
        instgram_link = request.POST.get('instgram_link')

        if name == "" or email == "":
            notify = "All fields requred!"
            return render(request,'back/notify.html')
        else:
            try:
                db = Front_setting.objects.get(pk=1)
                db.name=name
                db.intro_title=intro_title
                db.itro_desctiption=intro_description
                db.intro_title1=intro_title1
                db.intro_description1=intro_description1
                db.intro_description2=intro_description2
                db.email=email
                db.address1=address1
                db.address2=address2
                db.fb=fb_link
                db.linkedIn=linkedin_link
                db.twttr=twt_link
                db.instgrm=instgram_link
                db.save()
                return redirect('homePageData')
            except:
                db = Front_setting.objects.get(pk=1)
                db.name=name
                db.intro_title=intro_title
                db.itro_desctiption=intro_description
                db.intro_title1=intro_title1
                db.intro_description1=intro_description1
                db.intro_description2=intro_description2
                db.email=email
                db.address1=address1
                db.address2=address2
                db.fb=fb_link
                db.linkedIn=linkedin_link
                db.twttr=twt_link
                db.instgrm=instgram_link
                db.save()
                return redirect('homePageData')

    homePage_data = Front_setting.objects.get(pk=1)



    return render(request,'edit-back/edit_home.html',{'home_page_data':homePage_data})

# home page ended

# about page started
def about_page_data(request):

    about_pageData = About_page.objects.get(pk=1)

    return render(request,'back/aboutPage_data.html',{'about_pageData':about_pageData})

def add_about(request):

    if not request.user.is_authenticated:
        return render(request,'back/login.html')

    if request.method == 'POST':
        name = request.POST.get('name')
        myqoute = request.POST.get('myqoute')
        about1 = request.POST.get('about1')
        about2 = request.POST.get('about2')
        qoute = request.POST.get('qoute')

        if name != '' and about1 != '' and about2 != '':
            b = About_page.objects.get(pk=1)
            b.name = name
            b.myqoute = myqoute
            b.about1 = about1
            b.about2 = about2
            b.qoute = qoute
            b.save()
            return redirect('aboutPageData')
        else:
            notify = "All the fields required!"
            return render(request,'back/notify.html',{'notify':notify})

    return render(request, 'back/add_about.html')

def edit_about(request):

    if not request.user.is_authenticated:
        return render(request,'back/login.html')

    if request.method == 'POST':
        name = request.POST.get('name')
        myqoute = request.POST.get('myqoute')
        about1 = request.POST.get('about1')
        about2 = request.POST.get('about2')
        qoute = request.POST.get('qoute')

        if name != '' and about1 != '' and about2 != '':
            try:
                b = About_page.objects.get(pk=1)
                b.name = name
                b.myqoute = myqoute
                b.about1 = about1
                b.about2 = about2
                b.qoute = qoute
                b.save()
                return redirect('aboutPageData')
            except:
                b = About_page.objects.get(pk=1)
                b.name = name
                b.myqoute = myqoute
                b.about1 = about1
                b.about2 = about2
                b.qoute = qoute
                b.save()
                return redirect('aboutPageData')
        else:
            notify = "All the fields required!"
            return render(request,'back/notify.html',{'notify':notify})

    about_page_data = About_page.objects.get(pk=1)

    return render(request,'edit-back/edit_about.html',{'aboutPage_data':about_page_data})
# about page ends

# skill page started

def skill_page_data(request):

    skill_page_data = Skill.objects.all()

    return render(request,'back/skillPage_data.html',{'skill_page_data':skill_page_data})

def add_skill(request):

    if not request.user.is_authenticated:
        return render(request,'back/login.html')

    if request.method == 'POST':
        name = request.POST.get('name')
        skill_title = request.POST.get('skill_title')
        skill_details = request.POST.get('skill_details')

        if name != '' and skill_title != '' and skill_details != '':
            try:
                b = Skill(name=name, skill_title=skill_title, skill_details=skill_details)
                b.save()
                return redirect('skillPageData')
            except:
                notify = "Data can't be saved!"
                return render(request,'back/notify.html',{'notify':notify})

        else:
            notify = "Empty fields are not allowed!"
            return render(request,'back/notify.html',{'notify':notify})

    return render(request,'back/add_skill.html')

def edit_skill(request,pk):

    if not request.user.is_authenticated:
        return render(request,'back/login.html')

    if request.method == 'POST':
        name = request.POST.get('name')
        skill_title = request.POST.get('skill_title')
        skill_details = request.POST.get('skill_details')

        if name != '' and skill_title != '' and skill_details != '':
            try:
                b = Skill.objects.get(pk=pk)
                b.name = name
                b.skill_title = skill_title
                b.skill_details = skill_details
                b.save()
                return redirect('skillPageData')

            except:
                b = Skill.objects.get(pk=pk)
                b.name = name
                b.skill_title = skill_title
                b.skill_details = skill_details
                b.save()
                return redirect('skillPageData')

        else:
            notify = "Empty fields are not allowed!"
            return render(request,'back/notify.html',{'notify':notify})
    skill_pageData = Skill.objects.get(pk=pk)

    return render(request,'edit-back/edit_skill.html',{'skill_pageData':skill_pageData,'pk':pk})

def del_skill(request,pk):

    if not request.user.is_authenticated:
        return render(request,'back/login.html')

    try:
        skill_pageData_del = Skill.objects.filter(pk=pk)
        skill_pageData_del.delete()
        return redirect('skillPageData')
    except:
        notify = "Can't be removed!"
        return render(request,'back/notify.html',{'notify':notify})

    return redirect('skillPageData')


# project part started

