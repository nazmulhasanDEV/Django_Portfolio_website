from django.conf.urls import url, include
from django.contrib import admin
from . import views


urlpatterns = [
    # home page starts
    url(r'^panel/add/home/$', views.add_home, name='addHome'),
    url(r'^panel/home/pageData/$', views.home_page_data, name='homePageData'),
    url(r'^panel/edit/home/$', views.edit_homePage, name='editHomePage'),

    # about page starts
    url(r'^panel/about/pageData/$', views.about_page_data, name='aboutPageData'),
    url(r'^panel/add/about/$', views.add_about, name='addAboutPage'),
    url(r'^panel/edit/about/$', views.edit_about, name='editAboutPage'),

    # skill page starts
    url(r'^panel/skill/pageData/$', views.skill_page_data, name='skillPageData'),
    url(r'^panel/add/skill/$', views.add_skill, name='addSkillPage'),
    url(r'^panel/edit/skill/(?P<pk>\d+)/$', views.edit_skill, name='editSkillPage'),
    url(r'^panel/del/skill/(?P<pk>\d+)/$', views.del_skill, name='deleteSkillPage'),
]
