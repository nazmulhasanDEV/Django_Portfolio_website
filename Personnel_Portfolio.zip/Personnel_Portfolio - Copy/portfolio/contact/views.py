from django.shortcuts import render, redirect, get_object_or_404
from .models import Contact, Messages
# Create your views here.

def contact_info_list(request):

    contact_info  = Contact.objects.get(pk=1)

    return render(request,'back/contact_info_list.html',{'contact_info':contact_info})


def contact_info_edit(request):

    if not request.user.is_authenticated:
        return render(request,'back/login.html')

    if request.method == 'POST':

        address = request.POST.get('address')
        address1 = request.POST.get('address1')
        phone = request.POST.get('phone')
        email = request.POST.get('email')

        if address == '' or address1 == '' or phone == '' or email == '':
            notify = "Empty fields are not allowed!"
            return render(request,'back/notify.html',{'notify':notify})
        else:
            try:
                b = Contact.objects.get(pk=1)
                b.address = address
                b.address1 = address1
                b.contact_phone = phone
                b.contact_email = email
                b.save()
                return redirect('contactInfoList')

            except:
                b = Contact.objects.get(pk=1)
                b.address = address
                b.address1 = address1
                b.contact_phone = phone
                b.contact_email = email
                b.save()
                return redirect('contactInfoList')

    contact_info = Contact.objects.get(pk=1)

    return render(request,'edit-back/edit_contact_info.html',{'contact_info':contact_info})

def client_message_list(request):

    messages = Messages.objects.all()

    return render(request,'back/client_msg_list.html',{'messages':messages})

def client_message_delete(request,pk):

    if not request.user.is_authenticated:
        return render(request,'back/login.html')

    try:
        messages = Messages.objects.filter(pk=pk)
        messages.delete()
        return redirect('clientMsgList')
    except:
        notify = "Can't be removed!"
        return render(request,'back/notify.html',{'notify':notify})

    return redirect('clientMsgList')
