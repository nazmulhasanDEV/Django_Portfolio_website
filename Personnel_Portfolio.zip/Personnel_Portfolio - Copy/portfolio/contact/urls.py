from django.conf.urls import url, include
from . import views

urlpatterns = [

    # contact info section
    url(r'^panel/contact/info/list/$',views.contact_info_list, name='contactInfoList'),
    url(r'^panel/edit/contact/info/$',views.contact_info_edit, name='editContactInfo'),

    # client message section
    url(r'^panel/client/message/list/$',views.client_message_list, name='clientMsgList'),
    url(r'^panel/client/message/del/(?P<pk>\d+)/$',views.client_message_delete, name='clientMsgDel'),

]
