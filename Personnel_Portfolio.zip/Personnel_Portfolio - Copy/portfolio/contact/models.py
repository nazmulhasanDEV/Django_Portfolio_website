from __future__ import  unicode_literals
from django.db import models


# Create your models here.

class Contact(models.Model):

    contact_info = models.CharField(default='Contact Me', max_length=15)
    address = models.CharField(default='Dhaka, Dhanmondi', max_length=50)
    address1 = models.CharField(default='Dhaka, Dhanmondi', max_length=50)
    contact_phone = models.IntegerField(default=0)
    contact_email = models.CharField(default='example@gmail.com', max_length=30)

    def __str__(self):
        return self.contact_info+'|'+str(self.pk)

class Messages(models.Model):

    name = models.CharField(default='Message List', max_length=15)
    msg_txt = models.TextField(default='Enter your message', max_length=150)
    visitor_name = models.CharField(default='Enter your name', max_length=25)
    visitor_email = models.CharField(default='Enter your email', max_length=40)

    def __str__(self):
        return self.name +'|'+str(self.pk)
