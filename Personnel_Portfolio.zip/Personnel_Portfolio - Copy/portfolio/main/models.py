from __future__ import unicode_literals
from django.db import models

# Create your models here.

class Front_setting(models.Model):

    name = models.CharField(default="Portfolio", max_length=30)
    intro_title = models.TextField(default='I am a web designer....')
    itro_desctiption = models.TextField(default="Intro description....")

    intro_title1 = models.TextField(default="Designing is my passion...")
    intro_description1 = models.TextField(default="Passion....")
    intro_description2 = models.TextField(default="Passion....")

    email = models.CharField(default='E-mail', max_length=35)

    address1 = models.TextField(default="Address1")
    address2 = models.TextField(default="Address2")

    fb = models.CharField(default='Facebook Link', max_length=75)
    linkedIn = models.CharField(default='Linked Link', max_length=75)
    twttr = models.CharField(default='Twitter Link', max_length=74)
    instgrm = models.CharField(default='Instagram Link',max_length=75)

    def __str__(self):
        return self.name +'|'+ str(self.pk)


class About_page(models.Model):

    name = models.CharField(default='About page', max_length=50)
    myqoute = models.TextField(default='My Qoute', max_length=50)
    about1 = models.TextField(default='About me-1')
    about2 = models.TextField(default='About me-2')
    qoute = models.TextField(default='Qoute')

    def __str__(self):
        return self.name+'|'+str(self.pk)

class Skill(models.Model):

    name = models.CharField(default='Skill',max_length=60)
    skill_title = models.TextField(default='Skill Title')
    skill_details = models.TextField(default="Skill Details")

    def __str__(self):
        return self.name+'|'+str(self.pk)


