from django.contrib import admin
from .models import Front_setting, About_page, Skill

# Register your models here.

admin.site.register(Front_setting)
admin.site.register(About_page)
admin.site.register(Skill)
