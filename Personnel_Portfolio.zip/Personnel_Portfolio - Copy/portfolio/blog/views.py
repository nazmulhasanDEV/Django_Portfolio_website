from django.shortcuts import render,redirect, get_object_or_404
from .models import Category,Sub_category,News, Comment
from django.core.files.storage import FileSystemStorage
import datetime
from main.models import Front_setting
from django.core.paginator import PageNotAnInteger,Paginator,EmptyPage
# Create your views here.

# Category sections
def category_list(request):

    if request.method == 'POST':
        category_name = request.POST.get('cat_name')
        if category_name == "":
            notify = "Empty fields are not allowed!"
            return render(request,'back/notify.html',{'notify':notify})

        else:
            try:
                if len(Category.objects.filter(category_name=category_name)) == 0:
                    b = Category(category_name=category_name)
                    b.save()
                    return redirect('categoryList')
                else:
                    notify = "This category name already exists!"
                    return render(request,'back/notify.html',{'notify':notify})

            except:
                notify = "Can't be saved!"
                return render(request,'back/notify.html',{'notify':notify})

    categories = Category.objects.all()
    return render(request,'back-blog/category_list.html',{'categories':categories})

def category_delete(request,pk):

    try:
        b = Category.objects.filter(pk=pk)
        b.delete()
        c = Sub_category.objects.filter(category_id=pk)
        c.delete()
        redirect('categoryList')
    except:
        notify = "Can't be deleted!"
        return render(request,'back/notify.html',{'notify':notify})

    return redirect('categoryList')

# Sub-category Sections

def sub_category_list(request):

    categories = Category.objects.all()

    if request.method == 'POST':

        sub_category_name = request.POST.get('sub_cat_name')
        category_code = request.POST.get('category_name')

        if sub_category_name == '':
            notify = "Empty fields are not allowed!"
            return render(request,'back/notify.html',{'notify':notify})
        else:
            try:
                if len(Sub_category.objects.filter(sub_category_name=sub_category_name)) == 0:

                    category = Category.objects.get(pk=category_code)
                    cat_name = category.category_name
                    b = Sub_category(sub_category_name=sub_category_name,category_name=cat_name,category_id=category_code)
                    b.save()
                    return redirect('subCategoryList')
                else:
                    notify = "This name aready exists!"
                    return render(request,'back/notify.html',{'notify':notify})
            except:
                notify = "Can't be saved!"
                return render(request,'back/notify.html',{'notify':notify})

    sub_cat_list = Sub_category.objects.all()

    return render(request,'back-blog/sub_category_list.html',{'categories':categories,'sub_cat_list':sub_cat_list})

def sub_category_delete(request,pk):

    try:
        b = Sub_category.objects.filter(pk=pk)
        b.delete()
        redirect('subCategoryList')
    except:
        notify = "Can't be deleted!"
        return render(request,'back/notify.html',{'notify':notify})

    return redirect('subCategoryList')

# News article section

def new_list(request):

    newsm = News.objects.all()
    perm = 1

    if perm==1:
        newss = News.objects.all()
        paginator = Paginator(newss,1)
        page = request.GET.get('page')
        try:
            news = paginator.page(page)
        except EmptyPage:
            news = paginator.page(paginator.num_pages)
        except PageNotAnInteger:
            news = paginator.page(1)

    return render(request,'back-blog/news_list.html',{'news':news})

def add_news(request):

    if not request.user.is_authenticated:
        return render(request,'back/login.html')

    date_time = datetime.datetime.now()
    year = date_time.year
    month = date_time.month
    day = date_time.day
    hour = date_time.hour
    minute = date_time.minute

    if len(str(day))  == 1: day = '0'+str(day)
    if len(str(month))  == 1: day = '0'+str(month)
    actual_date = str(month)+'/'+str(day)+'/'+str(year)+' | '+str(hour)+':'+str(minute)

    news_categories = Category.objects.all()
    news_sub_category = Sub_category.objects.all()

    if request.method == 'POST':

        news_title = request.POST.get('news_title')
        news_description = request.POST.get('news_description')
        news_sub_category_id = request.POST.get('news_category_name')
        news_tags = request.POST.get('tags')

        if news_title == '' or news_description == '' or news_sub_category_id == '' or news_tags == '':
            notify = "Empty fields are not allowed!"
            return render(request,'back/notify.html',{'notify':notify})

        else:
            try:
                news_file = request.FILES['news_img']
                fs = FileSystemStorage()
                # justifying whether it's an image or not

                convert_file_name = str(news_file)
                file_extension = convert_file_name.split('.')
                original_extension = file_extension[len(file_extension)-1].lower()

                if original_extension == 'png' or original_extension == 'jpg' or original_extension == 'jpeg':

                    img_name = fs.save(news_file.name,news_file)
                    img_url = fs.url(img_name)

                    news_sub_cat= Sub_category.objects.get(pk=news_sub_category_id)
                    news_category_name = news_sub_cat.category_name
                    news_sub_category_name = news_sub_cat.sub_category_name
                    category_id = news_sub_cat.category_id

                    b = News(news_title=news_title,news_description=news_description,news_img_url=img_url,news_img_name=img_name,news_category= news_category_name,news_sub_category=news_sub_category_name,news_publish_date=actual_date,category_id=category_id,subcategory_id=news_sub_category_id,tags=news_tags)
                    b.save()

                    numberOf_news_Bycategory = len(News.objects.filter(category_id=category_id))
                    category  = Category.objects.get(pk=category_id)
                    category.numberOf_news_by_category = numberOf_news_Bycategory
                    category.save()
                    return redirect('newsList')

                else:
                    notify = "Only images are alllowed!"
                    return render(request,'back/notify.html',{'notify':notify})
            except:
                notify = "Can't be saved your post!"
                return render(request,'back/notify.html',{'notify':notify})

    return render(request,'back-blog/add_news.html',{'news_category':news_categories,'news_subcat':news_sub_category})

def news_delete(request,pk):

    if not request.user.is_authenticated:
        return render(request,'back/login.html')

    try:
        b = News.objects.get(pk=pk)
        fs = FileSystemStorage()
        fs.delete(b.news_img_name)
        b.delete()
        category_id = b.category_id
        numberOf_news_Bycategory = len(News.objects.filter(category_id=category_id))
        category  = Category.objects.get(pk=category_id)
        category.numberOf_news_by_category = numberOf_news_Bycategory
        category.save()
        return redirect('newsList')
    except:
        notify = "Can't be deleted!"
        return redirect(request,'back/notify.html',{'notify':notify})

    return redirect('newsList')

def news_edit(request,pk):

    if not request.user.is_authenticated:
        return render(request,'back/login.html')


    if request.method == 'POST':
        news_title = request.POST.get('news_title')
        news_description = request.POST.get('news_description')
        cat_subcat_id = request.POST.get('news_category_id')
        news_tags = request.POST.get('news_tags')

        if news_title == '' or news_description == '' or cat_subcat_id == '' or news_tags == '':
            notify = "Empty fields are not allowed!"
            return render(request,'back/notify.html',{'notify':notify})

        else:
            try:
                news_file = request.FILES['news_img']
                fs = FileSystemStorage()
                # justifying whether it's an image or not

                convert_file_name = str(news_file)
                file_extension = convert_file_name.split('.')
                original_extension = file_extension[len(file_extension)-1].lower()

                if original_extension == 'png' or original_extension == 'jpg' or original_extension == 'jpeg':

                    img_name = fs.save(news_file.name,news_file)
                    img_url = fs.url(img_name)

                    news_sub_cat= Sub_category.objects.get(pk=cat_subcat_id)
                    news_category_name = news_sub_cat.category_name
                    news_sub_category_name = news_sub_cat.sub_category_name
                    category_id = news_sub_cat.category_id

                    b = News.objects.get(pk=pk)
                    fs.delete(b.news_img_name)

                    b.news_title = news_title
                    b.news_description = news_description
                    b.news_img_url = img_url
                    b.news_img_name = img_name
                    b.news_category = news_category_name
                    b.news_sub_category = news_sub_category_name
                    b.category_id = category_id
                    b.subcategory_id = cat_subcat_id
                    b.tags = news_tags
                    b.save()

                    numberOf_news_Bycategory = len(News.objects.filter(category_id=category_id))
                    category  = Category.objects.get(pk=category_id)
                    category.numberOf_news_by_category = numberOf_news_Bycategory
                    category.save()

                    return redirect('newsList')

                else:
                    notify = "Only images are alllowed!"
                    return render(request,'back/notify.html',{'notify':notify})
            except:

                news_sub_cat= Sub_category.objects.get(pk=cat_subcat_id)
                news_category_name = news_sub_cat.category_name
                news_sub_category_name = news_sub_cat.sub_category_name
                category_id = news_sub_cat.category_id

                b = News.objects.get(pk=pk)

                will_replace_catid = b.category_id

                b.news_title = news_title
                b.news_description = news_description
                b.news_category = news_category_name
                b.news_sub_category = news_sub_category_name
                b.category_id = category_id
                b.subcategory_id = cat_subcat_id
                b.save()

                numberOf_news_Bycategory = len(News.objects.filter(category_id=category_id))
                category  = Category.objects.get(pk=category_id)
                category.numberOf_news_by_category = numberOf_news_Bycategory
                category.save()

                lenOf_category_news = len(News.objects.filter(category_id=will_replace_catid))
                newsCategory_name = Category.objects.get(pk=will_replace_catid)
                newsCategory_name.numberOf_news_by_category = lenOf_category_news
                newsCategory_name.save()

                return redirect('newsList')

    news_to_edit = News.objects.get(pk=pk)
    sub_categories = Sub_category.objects.all()

    return render(request,'edit-back/edit_news.html',{'pk':pk,'news_to_edit':news_to_edit,'sub_cats':sub_categories})

def news_details(request,pk):

    site_details = Front_setting.objects.get(pk=1)
    news = News.objects.get(pk=pk)

    news_tags = news.tags
    news_tags_split = news_tags.split(',')

    categories = Category.objects.all()

    recent_posts = News.objects.all().order_by('-pk')[:3]

    # grabing data from comment section
    if request.method == 'POST':
        comment_txt = request.POST.get('comment')
        visitor_name = request.POST.get('name')

        if comment_txt == '' or visitor_name == '':
            notify = "Empty fields are not alllowed!"
            return render(request,'front/notify.html',{'notify':notify})
        else:
            try:
                date_time = datetime.datetime.now()
                year = date_time.year
                month = date_time.month
                day = date_time.day
                hour = date_time.hour
                minute = date_time.minute

                if len(str(day))  == 1: day = '0'+str(day)
                if len(str(month))  == 1: day = '0'+str(month)
                actual_date = str(month)+'/'+str(day)+'/'+str(year)+' | '+str(hour)+':'+str(minute)

                b = Comment(commentator_name=visitor_name,comment_txt=comment_txt,news_pk=pk,date_time=actual_date)
                b.save()

                numberOf_comments = len(Comment.objects.filter(news_pk=pk))
                news_db = News.objects.get(pk=pk)
                news_db.numberOf_comments = numberOf_comments
                news_db.save()

            except:
                notify = "Empty fields are not alllowed!"
                return render(request,'front/notify.html',{'notify':notify})

    comments = Comment.objects.all()
    numberOf_news_comment = News.objects.get(pk=pk)


    return render(request,'front/news_details.html',{'site_details':site_details,'selected_news':news,'categories':categories,'recent_post':recent_posts,'news_tags':news_tags_split,'pk':pk,'comments':comments,'numberOf_commnt':numberOf_news_comment})

# Comment section

def comment_list(request):

    comments = Comment.objects.all()
    # numberOf_news_comment = News.objects.all()

    return render(request,'back-blog/comment_list.html',{'comments':comments})

def comment_delete(request,pk):

    if not request.user.is_authenticated:
        return render(request,'back/login.html')

    try:

        b = Comment.objects.get(pk=pk)
        news_pk = b.news_pk
        b.delete()

        c = len(Comment.objects.filter(news_pk=news_pk))
        news = News.objects.get(pk=news_pk)
        news.numberOf_comments  = c
        news.save()
        return redirect('commentList')

    except:
        notify = "Can't be deleted!"
        return render(request,'back/notify.html',{'notify':notify})
    return redirect('commentList')

