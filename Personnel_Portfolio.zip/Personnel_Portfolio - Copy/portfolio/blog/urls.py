from django.conf.urls import url, include
from . import views

urlpatterns = [
    # category list
    url(r'^panel/category/list/$', views.category_list, name='categoryList'),
    url(r'^panel/category/del/(?P<pk>\d+)/$', views.category_delete, name='categoryDel'),

    #Sub-category list

    url(r'^panel/sub_catgory/list/$', views.sub_category_list, name='subCategoryList'),
    url(r'^panel/sub_category/del/(?P<pk>\d+)/$', views.sub_category_delete, name='subCategoryDel'),

    #News section
    url(r'^panel/news/list/$',views.new_list, name='newsList'),
    url(r'^panel/add/news/$',views.add_news, name='addNews'),
    url(r'^panel/del/news/(?P<pk>\d+)/$',views.news_delete, name='newsDel'),
    url(r'^panel/edit/news/(?P<pk>\d+)/$',views.news_edit, name='newsEdit'),
    url(r'^panel/news/details/(?P<pk>\d+)/$',views.news_details, name='newsDetails'),

    # comment section
    url(r'^panel/comment/list/$',views.comment_list, name='commentList'),
    url(r'^panel/comment/del/(?P<pk>\d+)/$',views.comment_delete, name='commentDel'),

]
