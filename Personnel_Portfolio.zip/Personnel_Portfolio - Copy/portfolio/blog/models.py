from __future__ import unicode_literals
from django.db import models

# Create your models here.

class Category(models.Model):

    category_name = models.CharField(default='Category Name', max_length=25)
    numberOf_news_by_category = models.IntegerField(default=0)

    def __str__(self):
        return self.category_name+'|'+str(self.pk)

class Sub_category(models.Model):

    sub_category_name = models.CharField(default='Sub-cat',max_length=20)
    category_name = models.CharField(default='Sub-cat',max_length=20)
    category_id = models.IntegerField(default=0)

    def __str__(self):
        return self.sub_category_name+'|'+str(self.pk)

class News(models.Model):

    news_title = models.CharField(default='News Title',max_length=60)
    news_description = models.TextField(default='News Description')
    news_img_url = models.CharField(default='News Image Url',max_length=60)
    news_img_name = models.CharField(default='News Image Name',max_length=60)
    news_category = models.CharField(default='News Category', max_length=20)
    news_sub_category = models.CharField(default='News Sub-Category', max_length=20)
    news_publish_date = models.CharField(default='News Publish Date',max_length=60)
    category_id = models.IntegerField(default=0)
    subcategory_id = models.IntegerField(default=0)
    tags = models.TextField(default="Tags")
    numberOf_comments = models.IntegerField(default=0)

    def __str__(self):
        return self.news_title+'|'+str(self.pk)


class Comment(models.Model):

    commentator_name = models.CharField(default='Nazmul Hasan',max_length=20)
    comment_txt = models.TextField(default='Comment')
    news_pk = models.IntegerField(default=0)
    date_time = models.CharField(default='Date Time', max_length=30)

    def __str__(self):
        return self.commentator_name+'|'+str(self.pk)




